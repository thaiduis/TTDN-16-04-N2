# -*- coding: utf-8 -*-

from . import phong_ban
from . import ky_nang
from . import nhan_vien
from . import cham_cong
from . import bang_luong
from . import hr_bonus_log
from . import hr_integration
from . import hr_id_ocr_connector
from . import id_ocr_service
from . import id_ocr_log

