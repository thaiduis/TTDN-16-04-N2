# -*- coding: utf-8 -*-

from . import task_checklist
from . import project_task
from . import task_smart_report
from . import task_score_card
from . import task_api_connector
from . import task_git_integration
from . import task_ai_assistant
from . import task_unified_dashboard
from . import task_analytics_report
from . import task_sentiment_analyzer
# Import task_hr_integration LAST to ensure nhan_vien model is available
from . import task_hr_integration
