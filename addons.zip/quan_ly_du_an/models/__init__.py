# -*- coding: utf-8 -*-

from . import project_project
from . import project_milestone
from . import project_okr
from . import project_hr_integration
from . import project_okr
